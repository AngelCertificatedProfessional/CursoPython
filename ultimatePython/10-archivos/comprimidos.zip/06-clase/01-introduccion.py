mensaje = "Hola mundo"
print(type(mensaje))

# Clase: es el plano de construccion de una casa
# Objeto: una instancia de una clase
