from ..gestion.crud import guardar


def pagar_impuestos():
    print("pagando impuestos")
    guardar()
