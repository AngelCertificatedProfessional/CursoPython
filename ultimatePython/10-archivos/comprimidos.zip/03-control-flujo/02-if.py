edad = 10
if edad > 54:
    print("Puede ver la pelicula con descuento")
elif edad > 17:
    print("Puede ver la pelicula")
else:
    print("No puedes entrar")
print("Listo")
