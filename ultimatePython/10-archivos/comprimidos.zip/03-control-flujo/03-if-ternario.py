edad = 118

mensaje = "Es mayor" if edad > 17 else "Es Menor"

# if edad > 17:
#     mensaje = "es mayor"
# else:
#     mensaje = "es menor"
print(mensaje)
