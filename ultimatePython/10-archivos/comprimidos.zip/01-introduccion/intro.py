"""Introduccion a Python"""
print("hola mundo !")
print("hola mundo !" * 4)
