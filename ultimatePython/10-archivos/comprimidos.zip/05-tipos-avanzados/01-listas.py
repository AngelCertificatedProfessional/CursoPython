numeros = [1, 2, 3]
letras = ["a", "b", "c"]
palabras = ["chachito", "feliz"]
palabrasFelices = ["chachito", "feliz", "Felipe", "alumno"]
bloeans = ["chachito", "feliz", "Felipe", "alumno"]
matriz = [[0, 1], [1, 0]]
ceros = [0, 1] * 10  # multiplica el contenido por el valor
alfanumerico = numeros + letras
rango = list(range(1, 11))  # desde el uno hasta el 10
chars = list("Hola mundo")
print(chars)
