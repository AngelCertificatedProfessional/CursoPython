mascotas = ["Pelusa", "Pulga", "Felipe", "Pulga",  "Chanchito Feliz"]

print(mascotas.count("Pulga"))
if "Pulga" in mascotas:
    print(mascotas.index("Pulga"))
