nombre = "Nicolas"
apellido = "Schurmann"
# concatenar el nombre con el apellido
nombre_completo = f"{nombre} {apellido}"
print(nombre_completo)
# concatenar el nombre con el apellido
test = f"{nombre[0]} {2+5}"
print(test)
