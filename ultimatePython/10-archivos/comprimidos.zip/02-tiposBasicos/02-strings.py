nombre_curso = "Ultimate Python"
descripcion_curso = """
Ultimate Python,
este curso contempla todos los detalles
que ocupa un desarrollador 
para tener un trabajo
"""
print(nombre_curso, descripcion_curso)
print(len(nombre_curso))
print(nombre_curso[0])
print(nombre_curso[0:8])  # donde inicia : donde termina
print(nombre_curso[9:])  # inicia en 9 : termina hasta el final
print(nombre_curso[:8])  # inicia en 0 : termina hasta el 8
