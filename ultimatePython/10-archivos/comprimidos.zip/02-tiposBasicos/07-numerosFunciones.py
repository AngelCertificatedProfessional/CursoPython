import math

print(round(1.3))
print(round(1.7))
print(round(1.5))
print(abs(-77))
print(abs(55))
# va a tomar el valor y lo va a llevar al numero superior mas cercano
print(math.ceil(1.1))
# va a tomar el valor y lo va a llevar al numero inferior mas cercano
print(math.floor(1.9999))
print(math.isnan(23))  # va a evaluar si el valor es valor es o no un numro
print(math.pow(10, 3))  # eleva el valor a de 10 por 3
print(math.sqrt(9))  # raiz cuadrada del valor
