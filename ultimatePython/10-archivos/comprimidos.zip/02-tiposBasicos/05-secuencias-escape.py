# comentarios
# \"
# \ '
# \\
# \n
curso = "Ultimate \n \"Python\""
print(curso)
