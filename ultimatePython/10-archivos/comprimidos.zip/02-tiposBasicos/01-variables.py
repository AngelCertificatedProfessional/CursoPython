nombre_curso = "Ultimate Python"
print(nombre_curso)
