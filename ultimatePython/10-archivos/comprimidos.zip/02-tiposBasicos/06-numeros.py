numero = 2  # entero
decimal = 1.2  # float
imaginario = 2+2j  # 2 + 2j (j) raiz cuadrada de menos 1

numero += 2
print("numero", numero)
print(1 + 3)
print(1 - 3)
print(1 * 3)
print(1 / 3)
print(1 // 3)  # divicion sin decimales
print(1 % 3)
print(1 ** 3)  # elevar el valor a 3
