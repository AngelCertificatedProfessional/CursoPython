def init(graphql, **_):
    print("soy modulo uno {graphql}")
