def init(db, api, **otros):
    print("soy modulo dos: {db} {api}")
